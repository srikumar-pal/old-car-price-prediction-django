from django.db import models

# No database model needed for this project
