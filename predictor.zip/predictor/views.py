from django.shortcuts import render
import pickle
import os

# project root directory (old_car_price_project)
BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))
    )
)

MODEL_PATH = os.path.join(BASE_DIR, "model.pkl")

model = pickle.load(open(MODEL_PATH, "rb"))

def home(request):
    return render(request, "index.html")

def predict(request):
    if request.method == "POST":
        year = int(request.POST["year"])
        price = float(request.POST["price"])
        kms = int(request.POST["kms"])
        fuel = int(request.POST["fuel"])
        seller = int(request.POST["seller"])
        transmission = int(request.POST["transmission"])
        owner = int(request.POST["owner"])

        prediction = model.predict([[year, price, kms, fuel, seller, transmission, owner]])

        return render(request, "result.html", {
            "result": round(prediction[0], 2)
        })
